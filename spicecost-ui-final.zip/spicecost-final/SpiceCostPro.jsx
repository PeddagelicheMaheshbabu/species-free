/**
 * SpiceCost Pro — Full Single-File React Application
 * Manufacturing Cost Analysis Platform
 * 12 product types · 300K SKUs · Multi-region pricing · FX conversion
 *
 * Usage:
 *   npm install react react-dom chart.js react-chartjs-2
 *   Import this file as your App component
 *
 * All pages included:
 *   Dashboard · SKU Explorer · Cost Breakdown · Cost Simulator
 *   Region Pricing · Freight Matrix · Audit Log · Bulk Import
 */

import { useState, useEffect, useCallback, useRef } from "react";
import {
  Chart as ChartJS,
  ArcElement,
  Tooltip,
  Legend,
  LineElement,
  CategoryScale,
  LinearScale,
  PointElement,
  BarElement,
} from "chart.js";
import { Doughnut, Line, Bar } from "react-chartjs-2";

ChartJS.register(
  ArcElement, Tooltip, Legend,
  LineElement, CategoryScale, LinearScale, PointElement, BarElement
);

// ─────────────────────────────────────────────────────────────────────────────
// CONSTANTS & DATA
// ─────────────────────────────────────────────────────────────────────────────

const PRODUCTS = [
  { code: "TRM", name: "Turmeric Powder",    pr: 184,  pm: 12.8, oh: 18.4, margin: 25, color: "#f59e0b" },
  { code: "RCH", name: "Red Chilli Powder",  pr: 210,  pm: 11.2, oh: 17.8, margin: 22, color: "#ef4444" },
  { code: "CUM", name: "Cumin (Jeera)",      pr: 320,  pm: 13.4, oh: 19.2, margin: 28, color: "#22c55e" },
  { code: "CPD", name: "Coriander Powder",   pr: 145,  pm: 10.6, oh: 17.0, margin: 24, color: "#10b981" },
  { code: "GMB", name: "Garam Masala Blend", pr: 260,  pm: 18.2, oh: 20.5, margin: 31, color: "#8b5cf6" },
  { code: "BPP", name: "Black Pepper",       pr: 480,  pm: 14.0, oh: 16.8, margin: 35, color: "#6366f1" },
  { code: "CDM", name: "Cardamom Pods",      pr: 1200, pm: 22.5, oh: 14.0, margin: 40, color: "#ec4899" },
  { code: "MST", name: "Mustard Seeds",      pr: 98,   pm: 9.4,  oh: 18.0, margin: 18, color: "#f59e0b" },
  { code: "FNG", name: "Fenugreek",          pr: 112,  pm: 10.0, oh: 17.5, margin: 19, color: "#06b6d4" },
  { code: "FNL", name: "Fennel Seeds",       pr: 175,  pm: 11.8, oh: 18.8, margin: 22, color: "#14b8a6" },
  { code: "CLV", name: "Cloves",             pr: 880,  pm: 16.0, oh: 15.0, margin: 38, color: "#f97316" },
  { code: "CIN", name: "Cinnamon",           pr: 520,  pm: 15.5, oh: 15.8, margin: 33, color: "#3b82f6" },
];

const REGIONS = [
  { id: "north_india", name: "North India",  freight: 14, currency: "INR", fxr: 1,      isExport: false },
  { id: "south_india", name: "South India",  freight: 18, currency: "INR", fxr: 1,      isExport: false },
  { id: "east_india",  name: "East India",   freight: 20, currency: "INR", fxr: 1,      isExport: false },
  { id: "west_india",  name: "West India",   freight: 16, currency: "INR", fxr: 1,      isExport: false },
  { id: "export_eu",   name: "Export — EU",  freight: 82, currency: "EUR", fxr: 90.18,  isExport: true  },
  { id: "export_us",   name: "Export — US",  freight: 95, currency: "USD", fxr: 83.42,  isExport: true  },
  { id: "export_me",   name: "Middle East",  freight: 60, currency: "AED", fxr: 22.71,  isExport: true  },
  { id: "export_sea",  name: "SE Asia",      freight: 55, currency: "SGD", fxr: 61.88,  isExport: true  },
];

const FX_RATES = [
  { currency: "USD", rate: 83.42,  region: "US Export",   status: "live"   },
  { currency: "EUR", rate: 90.18,  region: "EU Export",   status: "live"   },
  { currency: "GBP", rate: 105.74, region: "UK Export",   status: "live"   },
  { currency: "AED", rate: 22.71,  region: "Middle East", status: "cached" },
  { currency: "SGD", rate: 61.88,  region: "SE Asia",     status: "live"   },
  { currency: "SAR", rate: 22.24,  region: "Saudi Arabia",status: "live"   },
  { currency: "JPY", rate: 0.55,   region: "Japan",       status: "live"   },
  { currency: "AUD", rate: 54.12,  region: "Australia",   status: "cached" },
];

const FREIGHT_MATRIX = [
  { region: "North India", local: 12,  express: 22,  bulk: 8,   type: "domestic" },
  { region: "South India", local: 18,  express: 30,  bulk: 12,  type: "domestic" },
  { region: "East India",  local: 20,  express: 34,  bulk: 14,  type: "domestic" },
  { region: "West India",  local: 16,  express: 28,  bulk: 10,  type: "domestic" },
  { region: "Export — EU", local: 65,  express: 180, bulk: 240, type: "export"   },
  { region: "Export — US", local: 75,  express: 200, bulk: 260, type: "export"   },
  { region: "Middle East", local: 48,  express: 130, bulk: 170, type: "export"   },
  { region: "SE Asia",     local: 55,  express: 150, bulk: 200, type: "export"   },
];

const AUDIT_EVENTS = [
  { type: "COST_CHANGE", icon: "💰", sku: "TRM-5KG-NI",      user: "Priya K.",  field: "PR Cost/kg",    old: "₹178",    new_val: "₹184",    impact: "+3.4%",        impactType: "bad",  ts: "2025-05-14 09:12" },
  { type: "COST_CHANGE", icon: "📦", sku: "All Chilli SKUs",  user: "Rajan M.",  field: "Overhead %",    old: "17.9%",   new_val: "18.4%",   impact: "+0.5pp",       impactType: "bad",  ts: "2025-05-13 14:45" },
  { type: "COST_CHANGE", icon: "🚛", sku: "Export — EU",      user: "Sunita A.", field: "Freight Rate",  old: "₹18/kg",  new_val: "₹22/kg",  impact: "+22.2%",       impactType: "bad",  ts: "2025-05-12 11:00" },
  { type: "FX_UPDATE",   icon: "💱", sku: "Global",           user: "System",    field: "FX — EUR",      old: "88.90",   new_val: "90.18",   impact: "+1.44%",       impactType: "neu",  ts: "2025-05-10 08:30" },
  { type: "COST_CHANGE", icon: "📦", sku: "CUM-100G-SI",      user: "Priya K.",  field: "PM Cost/unit",  old: "₹14.20",  new_val: "₹12.80",  impact: "−9.9%",        impactType: "good", ts: "2025-05-08 16:22" },
  { type: "COST_CHANGE", icon: "💰", sku: "PEP-1KG-US",       user: "Rajan M.",  field: "List Price",    old: "$8.40",   new_val: "$9.10",   impact: "+Margin 2.1pp",impactType: "good", ts: "2025-05-07 10:05" },
  { type: "BULK_IMPORT", icon: "📤", sku: "12,400 SKUs",       user: "Admin",     field: "Bulk Import",   old: "—",       new_val: "q2_skus.xlsx", impact: "3 errors", impactType: "neu", ts: "2025-05-14 08:00" },
  { type: "COST_CHANGE", icon: "💰", sku: "CDM-250G-EU",       user: "Sunita A.", field: "PR Cost/kg",    old: "₹1150",   new_val: "₹1200",   impact: "+4.3%",        impactType: "bad",  ts: "2025-05-06 11:30" },
  { type: "FX_UPDATE",   icon: "💱", sku: "Global",            user: "System",    field: "FX — USD",      old: "82.85",   new_val: "83.42",   impact: "+0.69%",       impactType: "neu",  ts: "2025-05-05 00:00" },
];

const WEIGHTS = ["100G", "250G", "500G", "1KG", "5KG", "20KG"];
const REG_CODES = ["NI", "SI", "EU", "US", "ME"];

// ─────────────────────────────────────────────────────────────────────────────
// COST FORMULA
// ─────────────────────────────────────────────────────────────────────────────

function calcCost({ pr, pm, oh, freight, batchYield = 1, unitsPerKg = 1, margin, fxRate }) {
  const prC   = pr * batchYield;
  const pmC   = pm * unitsPerKg;
  const ohC   = prC * (oh / 100);
  const frC   = freight;
  const total = prC + pmC + ohC + frC;
  const price = total / (1 - margin / 100);
  const exportPrice = fxRate ? price / fxRate : null;
  return {
    prC: +prC.toFixed(2),
    pmC: +pmC.toFixed(2),
    ohC: +ohC.toFixed(2),
    frC: +frC.toFixed(2),
    total: +total.toFixed(2),
    price: +price.toFixed(2),
    exportPrice: exportPrice ? +exportPrice.toFixed(2) : null,
    prPct:  total ? +(prC / total * 100).toFixed(1) : 0,
    pmPct:  total ? +(pmC / total * 100).toFixed(1) : 0,
    ohPct:  total ? +(ohC / total * 100).toFixed(1) : 0,
    frPct:  total ? +(frC / total * 100).toFixed(1) : 0,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// STYLES (CSS-in-JS object)
// ─────────────────────────────────────────────────────────────────────────────

const S = {
  /* layout */
  shell:      { display:"flex", height:"100vh", fontFamily:"'DM Sans',system-ui,sans-serif", background:"#0e1120", overflow:"hidden" },
  sidebar:    { width:220, minWidth:220, background:"#0e1120", display:"flex", flexDirection:"column", borderRight:"1px solid #1a1f35" },
  sbLogo:     { padding:"20px 18px 16px", borderBottom:"1px solid #1a1f35" },
  sbBrand:    { fontSize:15, fontWeight:700, color:"#fff", display:"flex", alignItems:"center", gap:8 },
  sbSub:      { fontSize:10, color:"#3d4466", marginTop:3, letterSpacing:".08em", textTransform:"uppercase" },
  sbSection:  { fontSize:9, fontWeight:700, color:"#2d3252", padding:"14px 18px 4px", letterSpacing:".12em", textTransform:"uppercase" },
  sbFoot:     { padding:"14px 18px", borderTop:"1px solid #1a1f35", marginTop:"auto" },
  sbFootUser: { fontSize:11, color:"#4a5270", marginTop:2 },
  sbFootRole: { fontSize:10, color:"#2d3252" },

  main:       { flex:1, display:"flex", flexDirection:"column", overflow:"hidden", background:"#f0f2f7" },
  topbar:     { display:"flex", alignItems:"center", justifyContent:"space-between", padding:"0 24px", height:54, background:"#fff", borderBottom:"1px solid #e5e8f0", flexShrink:0 },
  content:    { flex:1, overflowY:"auto", padding:"20px 24px", display:"flex", flexDirection:"column", gap:16 },

  /* components */
  kpiRow:     { display:"grid", gridTemplateColumns:"repeat(5,minmax(0,1fr))", gap:10 },
  kpiCard:    { background:"#fff", borderRadius:10, border:"1px solid #e5e8f0", padding:"14px 16px" },
  kpiLabel:   { fontSize:11, color:"#8892b0", marginBottom:5, letterSpacing:".02em" },
  kpiVal:     { fontSize:22, fontWeight:700, color:"#1a1d27", lineHeight:1 },
  kpiDelta:   { fontSize:11, marginTop:5 },

  panels:     { display:"grid", gridTemplateColumns:"1fr 1fr", gap:14 },
  panel:      { background:"#fff", borderRadius:10, border:"1px solid #e5e8f0", padding:20, overflow:"hidden" },
  panelTitle: { fontSize:13, fontWeight:700, color:"#1a1d27", marginBottom:14, display:"flex", justifyContent:"space-between", alignItems:"center" },

  table:      { width:"100%", borderCollapse:"collapse", fontSize:12.5 },
  th:         { fontSize:10.5, fontWeight:700, color:"#8892b0", textAlign:"left", padding:"0 0 8px", borderBottom:"1px solid #f0f2f7", letterSpacing:".04em" },
  td:         { padding:"8px 0 8px 0", borderBottom:"1px solid #f7f8fc", color:"#2d3258", verticalAlign:"middle" },

  btn:        { fontSize:12, padding:"6px 14px", borderRadius:7, border:"1px solid #e0e3ef", background:"#fff", color:"#6872a0", cursor:"pointer", fontFamily:"inherit", outline:"none" },
  btnPrimary: { fontSize:12, padding:"6px 14px", borderRadius:7, border:"none", background:"#5b6ef5", color:"#fff", cursor:"pointer", fontFamily:"inherit", fontWeight:500 },
  select:     { fontSize:12, padding:"6px 12px", borderRadius:7, border:"1px solid #e0e3ef", background:"#fff", color:"#6872a0", cursor:"pointer", fontFamily:"inherit", outline:"none" },
};

// ─────────────────────────────────────────────────────────────────────────────
// SMALL COMPONENTS
// ─────────────────────────────────────────────────────────────────────────────

function Badge({ children, color = "#f0f2f7", text = "#6872a0" }) {
  return (
    <span style={{ fontSize:10, padding:"2px 8px", borderRadius:99, background:color, color:text, fontWeight:600, whiteSpace:"nowrap" }}>
      {children}
    </span>
  );
}

function Pill({ status, label }) {
  const MAP = {
    good:     ["#dcfce7","#166534"], bad:      ["#fee2e2","#991b1b"],
    neu:      ["#f0f2f7","#4a5270"], live:     ["#dcfce7","#166534"],
    cached:   ["#fef9c3","#854d0e"], export:   ["#dbeafe","#1e40af"],
    domestic: ["#dcfce7","#166534"], profitable:["#dcfce7","#166534"],
    marginal: ["#fef9c3","#854d0e"], loss:     ["#fee2e2","#991b1b"],
    done:     ["#dcfce7","#166534"], partial:  ["#fef9c3","#854d0e"],
    error:    ["#fee2e2","#991b1b"],
  };
  const [bg, fg] = MAP[status] || ["#f0f2f7","#4a5270"];
  return (
    <span style={{ fontSize:10, padding:"3px 9px", borderRadius:99, background:bg, color:fg, fontWeight:600 }}>
      {label || status}
    </span>
  );
}

function KpiCard({ label, value, delta, deltaType = "neu", sub }) {
  const colors = { bad:"#ef4444", good:"#22c55e", neu:"#8892b0" };
  return (
    <div style={S.kpiCard}>
      <div style={S.kpiLabel}>{label}</div>
      <div style={S.kpiVal}>{value}</div>
      {delta && <div style={{ ...S.kpiDelta, color: colors[deltaType] }}>{delta}</div>}
      {sub   && <div style={{ ...S.kpiDelta, color:"#8892b0" }}>{sub}</div>}
    </div>
  );
}

function NavItem({ icon, label, active, onClick }) {
  return (
    <div
      onClick={onClick}
      style={{
        display:"flex", alignItems:"center", gap:10, padding:"9px 18px",
        fontSize:12.5, cursor:"pointer", userSelect:"none", transition:"all .15s",
        color:      active ? "#fff"                      : "#5a6490",
        background: active ? "rgba(91,110,245,.15)"      : "transparent",
        borderLeft: active ? "2px solid #5b6ef5"         : "2px solid transparent",
        fontWeight: active ? 600                         : 400,
      }}
    >
      <span style={{ width:16, textAlign:"center", fontSize:14 }}>{icon}</span>
      {label}
    </div>
  );
}

function SectionHeader({ title, sub }) {
  return (
    <div style={{ marginBottom:4 }}>
      <h1 style={{ fontSize:20, fontWeight:700, color:"#1a1d27", margin:0 }}>{title}</h1>
      {sub && <p style={{ fontSize:12, color:"#8892b0", margin:"4px 0 0" }}>{sub}</p>}
    </div>
  );
}

function Table({ headers, rows, tdStyle = {} }) {
  return (
    <table style={S.table}>
      <thead>
        <tr>{headers.map((h, i) => <th key={i} style={S.th}>{h}</th>)}</tr>
      </thead>
      <tbody>
        {rows.map((row, ri) => (
          <tr key={ri}>
            {row.map((cell, ci) => (
              <td key={ci} style={{ ...S.td, ...(typeof tdStyle === "function" ? tdStyle(ri, ci, cell) : {}) }}>
                {cell}
              </td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function marginColor(m) {
  return m >= 28 ? "#22c55e" : m >= 22 ? "#f59e0b" : "#ef4444";
}

// ─────────────────────────────────────────────────────────────────────────────
// PAGE: DASHBOARD
// ─────────────────────────────────────────────────────────────────────────────

function PageDashboard() {
  const donutData = {
    labels: ["Raw Material (PR)", "Packaging (PM)", "Overhead", "Freight"],
    datasets: [{
      data: [46, 14, 20, 20],
      backgroundColor: ["#f59e0b","#8b5cf6","#22c55e","#3b82f6"],
      borderWidth: 0, hoverOffset: 6,
    }],
  };

  const productRows = PRODUCTS.slice(0, 8).map(p => {
    const res = calcCost({ pr:p.pr, pm:p.pm, oh:p.oh, freight:14, margin:p.margin });
    return [
      <span style={{ display:"flex", alignItems:"center", gap:7 }}>
        <span style={{ width:8, height:8, borderRadius:"50%", background:p.color, display:"inline-block", flexShrink:0 }} />
        {p.name}
      </span>,
      `₹${p.pr}`,
      `₹${p.pm}`,
      `${p.oh}%`,
      `₹${res.total}`,
      <span style={{ color:marginColor(p.margin), fontWeight:700 }}>{p.margin}%</span>,
    ];
  });

  return (
    <>
      <SectionHeader title="Cost Overview" sub="All products · All regions · Q2 2025" />
      <div style={S.kpiRow}>
        <KpiCard label="Total SKUs"       value="3,02,418"  sub="12 product types" />
        <KpiCard label="Avg PR ₹/kg"      value="₹184.50"  delta="↑ 3.2% MoM"   deltaType="bad"  />
        <KpiCard label="Avg PM ₹/unit"    value="₹12.80"   delta="↓ 1.1% MoM"   deltaType="good" />
        <KpiCard label="Overhead Rate"    value="18.4%"    delta="↑ 0.5pp MoM"  deltaType="bad"  />
        <KpiCard label="Avg Gross Margin" value="24.7%"    delta="↓ 2.1pp MoM"  deltaType="bad"  />
      </div>
      <div style={S.panels}>
        <div style={S.panel}>
          <div style={S.panelTitle}>Cost Component Split <Badge>All products</Badge></div>
          <div style={{ maxWidth:200, margin:"0 auto" }}>
            <Doughnut data={donutData} options={{ plugins:{ legend:{ display:false } }, cutout:"68%" }} />
          </div>
          <div style={{ display:"flex", justifyContent:"center", gap:12, marginTop:14, flexWrap:"wrap" }}>
            {[["#f59e0b","PR 46%"],["#8b5cf6","PM 14%"],["#22c55e","OH 20%"],["#3b82f6","Freight 20%"]].map(([c,l]) => (
              <span key={l} style={{ fontSize:11, display:"flex", alignItems:"center", gap:5, color:"#4a5270" }}>
                <span style={{ width:10, height:10, borderRadius:2, background:c, display:"inline-block" }} />{l}
              </span>
            ))}
          </div>
        </div>
        <div style={S.panel}>
          <div style={S.panelTitle}>Product Type Summary <Badge>8 of 12</Badge></div>
          <Table
            headers={["Product","PR ₹/kg","PM ₹/u","OH %","Total ₹/kg","Margin"]}
            rows={productRows}
          />
        </div>
      </div>
    </>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// PAGE: SKU EXPLORER
// ─────────────────────────────────────────────────────────────────────────────

function PageSKU() {
  const [activeType, setActiveType] = useState("ALL");
  const [search, setSearch] = useState("");
  const [regionFilter, setRegionFilter] = useState("all");

  const filtered = PRODUCTS.filter(p =>
    (activeType === "ALL" || p.code === activeType) &&
    (search === "" || p.name.toLowerCase().includes(search.toLowerCase()))
  );

  const skuCards = [];
  filtered.forEach((p, pi) => {
    WEIGHTS.slice(0, 2).forEach((w, wi) => {
      REG_CODES.slice(0, regionFilter === "all" ? 3 : 1).forEach((r, ri) => {
        if (regionFilter !== "all" && r !== regionFilter.toUpperCase()) return;
        const fRegion = REGIONS.find(reg => reg.id.includes(r.toLowerCase())) || REGIONS[0];
        const res = calcCost({ pr:p.pr, pm:p.pm, oh:p.oh, freight:fRegion.freight, margin:p.margin });
        skuCards.push({ sku:`${p.code}-${w}-${r}`, p, res, weight:w, region:r });
      });
    });
  });

  const shown = skuCards.slice(0, 12);

  return (
    <>
      <SectionHeader title="SKU Explorer" sub={`300K+ SKUs across 12 product types and 8 regions`} />
      {/* Filters bar */}
      <div style={{ background:"#fff", borderRadius:10, border:"1px solid #e5e8f0", padding:16 }}>
        <div style={{ display:"flex", gap:10, alignItems:"center", flexWrap:"wrap" }}>
          <input
            placeholder="Search product name…"
            value={search}
            onChange={e => setSearch(e.target.value)}
            style={{ ...S.select, flex:1, minWidth:180 }}
          />
          <select value={regionFilter} onChange={e => setRegionFilter(e.target.value)} style={S.select}>
            <option value="all">All Regions</option>
            {REGIONS.map(r => <option key={r.id} value={r.id}>{r.name}</option>)}
          </select>
        </div>
        <div style={{ display:"flex", gap:6, marginTop:12, flexWrap:"wrap" }}>
          {[{ code:"ALL", name:"All Types" }, ...PRODUCTS].map(p => (
            <button
              key={p.code}
              onClick={() => setActiveType(p.code)}
              style={{
                fontSize:11, padding:"4px 12px", borderRadius:99, border:"1px solid",
                cursor:"pointer", fontFamily:"inherit", transition:"all .15s",
                borderColor: activeType === p.code ? "#5b6ef5" : "#e0e3ef",
                background:  activeType === p.code ? "#5b6ef5" : "#fff",
                color:       activeType === p.code ? "#fff"    : "#6872a0",
              }}
            >
              {p.code === "ALL" ? "All" : p.code}
            </button>
          ))}
        </div>
      </div>

      {/* SKU Grid */}
      <div style={{ background:"#fff", borderRadius:10, border:"1px solid #e5e8f0", padding:20 }}>
        <div style={S.panelTitle}>
          SKU Results
          <Badge>{shown.length} shown of {skuCards.length}</Badge>
        </div>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:10 }}>
          {shown.map(({ sku, p, res, weight, region }) => (
            <div
              key={sku}
              style={{
                background:"#f8f9fc", borderRadius:9, border:"1px solid #e5e8f0",
                padding:"13px 14px", cursor:"pointer", transition:"all .15s",
              }}
              onMouseEnter={e => { e.currentTarget.style.borderColor="#5b6ef5"; e.currentTarget.style.boxShadow="0 2px 12px rgba(91,110,245,.12)"; }}
              onMouseLeave={e => { e.currentTarget.style.borderColor="#e5e8f0"; e.currentTarget.style.boxShadow="none"; }}
            >
              <div style={{ fontFamily:"monospace", fontSize:10, color:"#8892b0", marginBottom:4 }}>{sku}</div>
              <div style={{ fontSize:13, fontWeight:600, color:"#1a1d27", marginBottom:2 }}>{p.name}</div>
              <div style={{ fontSize:11, color:"#8892b0", marginBottom:10 }}>{weight} · {region} region</div>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                <span style={{ fontSize:15, fontWeight:700, color:"#5b6ef5" }}>₹{res.price}</span>
                <span style={{ fontSize:11, fontWeight:600, color:marginColor(p.margin) }}>+{p.margin}% margin</span>
              </div>
              <div style={{ marginTop:8, display:"flex", gap:6 }}>
                <span style={{ fontSize:10, color:"#8892b0" }}>PR ₹{res.prC}</span>
                <span style={{ fontSize:10, color:"#8892b0" }}>·</span>
                <span style={{ fontSize:10, color:"#8892b0" }}>OH ₹{res.ohC}</span>
                <span style={{ fontSize:10, color:"#8892b0" }}>·</span>
                <span style={{ fontSize:10, color:"#8892b0" }}>FR ₹{res.frC}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// PAGE: COST BREAKDOWN
// ─────────────────────────────────────────────────────────────────────────────

function PageCostBreakdown() {
  const trendData = {
    labels: ["Q3 2024","Q4 2024","Q1 2025","Q2 2025"],
    datasets: PRODUCTS.slice(0,5).map(p => ({
      label: p.name.split(" ")[0],
      data: [p.pr * 0.87, p.pr * 0.92, p.pr * 0.97, p.pr].map(v => Math.round(v)),
      borderColor: p.color,
      backgroundColor: "transparent",
      pointRadius: 4, tension: 0.35, borderWidth: 2,
    })),
  };

  const barData = {
    labels: PRODUCTS.map(p => p.code),
    datasets: [
      { label:"PR",      data:PRODUCTS.map(p => +(p.pr*0.25).toFixed(0)), backgroundColor:"#f59e0b" },
      { label:"PM",      data:PRODUCTS.map(p => p.pm),                    backgroundColor:"#8b5cf6" },
      { label:"Overhead",data:PRODUCTS.map(p => +(p.pr*0.25*(p.oh/100)).toFixed(0)), backgroundColor:"#22c55e" },
      { label:"Freight", data:PRODUCTS.map(() => 18),                     backgroundColor:"#3b82f6" },
    ],
  };

  const detailRows = PRODUCTS.slice(0, 8).map((p, i) => {
    const region = REGIONS[i % 2]; // domestic
    const res = calcCost({ pr:p.pr, pm:p.pm, oh:p.oh, freight:region.freight, margin:p.margin });
    const sku = `${p.code}-${WEIGHTS[i % 6]}-${REG_CODES[i % 3]}`;
    return [
      <span style={{ fontFamily:"monospace", fontSize:11 }}>{sku}</span>,
      p.name.split(" ")[0],
      `₹${res.prC}`,
      `₹${res.pmC}`,
      `₹${res.ohC}`,
      `₹${res.frC}`,
      <strong>₹{res.total}</strong>,
      <strong style={{ color:"#5b6ef5" }}>₹{res.price}</strong>,
      `$${(res.price / 83.42).toFixed(2)}`,
      <span style={{ color:marginColor(p.margin), fontWeight:700 }}>{p.margin}%</span>,
    ];
  });

  return (
    <>
      <SectionHeader title="Cost Breakdown" sub="Detailed PR · PM · Overhead · Freight analysis" />
      <div style={S.panels}>
        <div style={S.panel}>
          <div style={S.panelTitle}>PR Cost Trend ₹/kg <Badge>5 products · 4 quarters</Badge></div>
          <Line data={trendData} options={{
            scales: {
              y: { ticks:{ font:{size:10} }, grid:{ color:"#f5f5f7" } },
              x: { ticks:{ font:{size:10} }, grid:{ display:false } },
            },
            plugins: { legend:{ labels:{ font:{size:10}, boxWidth:10 } } },
          }} />
        </div>
        <div style={S.panel}>
          <div style={S.panelTitle}>Cost Component Stack <Badge>All 12 products</Badge></div>
          <Bar data={barData} options={{
            scales: {
              x: { stacked:true, ticks:{ font:{size:9} }, grid:{ display:false } },
              y: { stacked:true, ticks:{ font:{size:10} }, grid:{ color:"#f5f5f7" } },
            },
            plugins: { legend:{ labels:{ font:{size:10}, boxWidth:10 } } },
          }} />
        </div>
      </div>
      <div style={S.panel}>
        <div style={S.panelTitle}>Detailed Cost Register — SKU Level <Badge>8 of 3,02,418</Badge></div>
        <div style={{ overflowX:"auto" }}>
          <Table
            headers={["SKU Code","Product","PR ₹","PM ₹","OH ₹","Freight ₹","Total Cost","List Price","Export USD","Margin"]}
            rows={detailRows}
          />
        </div>
      </div>
      <div style={S.panels}>
        <div style={S.panel}>
          <div style={S.panelTitle}>Quarter-on-Quarter Change</div>
          <Table
            headers={["Component","Q2 2025","Q1 2025","Change"]}
            rows={[
              ["Raw Material (PR)", "₹184.50/kg", "₹178.90", <span style={{color:"#ef4444",fontWeight:700}}>+3.1%</span>],
              ["Packaging (PM)",    "₹12.80/unit","₹13.00",  <span style={{color:"#22c55e",fontWeight:700}}>−1.5%</span>],
              ["Overhead Rate",     "18.4%",       "17.9%",   <span style={{color:"#ef4444",fontWeight:700}}>+0.5pp</span>],
              ["Avg Freight",       "₹22.0/kg",   "₹18.0/kg",<span style={{color:"#ef4444",fontWeight:700}}>+22.2%</span>],
              ["Avg Total Cost",    "₹240/kg",     "₹228/kg", <span style={{color:"#ef4444",fontWeight:700}}>+5.3%</span>],
              ["Avg List Price",    "₹320/kg",     "₹310/kg", <span style={{color:"#ef4444",fontWeight:700}}>+3.2%</span>],
            ]}
          />
        </div>
        <div style={S.panel}>
          <div style={S.panelTitle}>Margin Analysis by Product</div>
          <Table
            headers={["Product","Total Cost","List Price","Margin","Status"]}
            rows={PRODUCTS.slice(0,8).map(p => {
              const res = calcCost({ pr:p.pr, pm:p.pm, oh:p.oh, freight:14, margin:p.margin });
              const status = p.margin>=28?"profitable":p.margin>=22?"marginal":"loss";
              return [
                p.name.split(" ")[0],
                `₹${res.total}`,
                `₹${res.price}`,
                <span style={{ color:marginColor(p.margin), fontWeight:700 }}>{p.margin}%</span>,
                <Pill status={status} label={status.charAt(0).toUpperCase()+status.slice(1)} />,
              ];
            })}
          />
        </div>
      </div>
    </>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// PAGE: COST SIMULATOR
// ─────────────────────────────────────────────────────────────────────────────

function PageSimulator() {
  const [params, setParams] = useState({ pr:184, pm:12.8, oh:18.4, freight:14, margin:25, fx:83.42, batchYield:1, unitsPerKg:1 });
  const [scenarios, setScenarios] = useState([]);
  const [scenarioName, setScenarioName] = useState("");
  const BASELINE = 240.30;

  const result = calcCost({ pr:params.pr, pm:params.pm, oh:params.oh, freight:params.freight, margin:params.margin, fxRate:params.fx, batchYield:params.batchYield, unitsPerKg:params.unitsPerKg });
  const delta = ((result.total - BASELINE) / BASELINE * 100);
  const status = params.margin >= 22 ? "profitable" : params.margin >= 12 ? "marginal" : "loss";

  const up = (key, val) => setParams(p => ({ ...p, [key]: parseFloat(val) || 0 }));

  const saveScenario = () => {
    if (!scenarioName.trim()) return;
    setScenarios(s => [...s, { name:scenarioName, ...params, ...result, ts:new Date().toLocaleTimeString() }]);
    setScenarioName("");
  };

  const SliderRow = ({ label, key, min, max, step=1, unit="₹", suffix="" }) => (
    <div style={{ marginBottom:18 }}>
      <div style={{ display:"flex", justifyContent:"space-between", marginBottom:6 }}>
        <span style={{ fontSize:12, color:"#4a5270" }}>{label}</span>
        <span style={{ fontSize:13, fontWeight:700, color:"#1a1d27" }}>{unit}{Number(params[key]).toFixed(step < 1 ? 1 : 0)}{suffix}</span>
      </div>
      <input type="range" min={min} max={max} step={step} value={params[key]}
        onChange={e => up(key, e.target.value)}
        style={{ width:"100%", accentColor:"#5b6ef5", height:4 }}
      />
      <div style={{ display:"flex", justifyContent:"space-between", fontSize:10, color:"#c0c8e8", marginTop:2 }}>
        <span>{unit}{min}{suffix}</span><span>{unit}{max}{suffix}</span>
      </div>
    </div>
  );

  return (
    <>
      <SectionHeader title="Cost Simulator" sub="Real-time what-if analysis across all cost components" />
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:14 }}>
        {/* Left: sliders */}
        <div style={S.panel}>
          <div style={S.panelTitle}>Input Parameters</div>
          <SliderRow label="Raw Material (PR) ₹/kg"     key="pr"         min={50}   max={1500} step={1}    />
          <SliderRow label="Packaging Material (PM) ₹/unit" key="pm"    min={2}    max={60}   step={0.1}  />
          <SliderRow label="Overhead Rate %"             key="oh"        min={5}    max={50}   step={0.1} unit="" suffix="%" />
          <SliderRow label="Freight ₹/kg"                key="freight"   min={0}    max={200}  step={1}   />
          <SliderRow label="Target Margin %"             key="margin"    min={5}    max={70}   step={0.5} unit="" suffix="%" />
          <SliderRow label="FX Rate (₹ per unit)"        key="fx"        min={20}   max={150}  step={0.01} />
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10 }}>
            <SliderRow label="Batch Yield"       key="batchYield"  min={0.5} max={1} step={0.01} unit="" />
            <SliderRow label="Units / kg"        key="unitsPerKg"  min={0.5} max={10} step={0.5} unit="" />
          </div>
        </div>
        {/* Right: results */}
        <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
          <div style={S.panel}>
            <div style={S.panelTitle}>Live Results</div>
            {[
              ["Total Cost / kg",     `₹${result.total}`,            null],
              ["Required List Price", `₹${result.price}`,            "#5b6ef5"],
              ["Export Price (USD)",  result.exportPrice ? `$${result.exportPrice}` : "—", null],
              ["Cost vs Baseline",    `${delta>=0?"+":""}${delta.toFixed(1)}%`, delta>0?"#ef4444":"#22c55e"],
              ["Break-even Price",    `₹${result.total}`,            null],
            ].map(([label, val, color]) => (
              <div key={label} style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"10px 0", borderBottom:"1px solid #f5f5f7" }}>
                <span style={{ fontSize:12, color:"#8892b0" }}>{label}</span>
                <span style={{ fontSize:16, fontWeight:700, color:color||"#1a1d27" }}>{val}</span>
              </div>
            ))}
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"12px 0" }}>
              <span style={{ fontSize:12, color:"#8892b0" }}>Status</span>
              <Pill status={status} label={status.charAt(0).toUpperCase()+status.slice(1)} />
            </div>
            {/* Cost bars */}
            <div style={{ background:"#f8f9fc", borderRadius:8, padding:14, marginTop:4 }}>
              <div style={{ fontSize:10, color:"#8892b0", fontWeight:700, marginBottom:10, letterSpacing:".06em" }}>COST BREAKDOWN %</div>
              {[["PR", result.prPct,"#f59e0b"],["PM",result.pmPct,"#8b5cf6"],["OH",result.ohPct,"#22c55e"],["Freight",result.frPct,"#3b82f6"]].map(([l,pct,c]) => (
                <div key={l} style={{ display:"flex", alignItems:"center", gap:8, marginBottom:7 }}>
                  <span style={{ fontSize:10, color:"#8892b0", width:40 }}>{l}</span>
                  <div style={{ flex:1, height:6, background:"#e8eaf2", borderRadius:3, overflow:"hidden" }}>
                    <div style={{ width:`${Math.min(pct,100)}%`, height:"100%", background:c, borderRadius:3, transition:"width .3s" }} />
                  </div>
                  <span style={{ fontSize:10, color:"#4a5270", width:36, textAlign:"right" }}>{pct.toFixed(0)}%</span>
                </div>
              ))}
            </div>
          </div>
          {/* Save scenario */}
          <div style={S.panel}>
            <div style={S.panelTitle}>Save Scenario</div>
            <div style={{ display:"flex", gap:8 }}>
              <input value={scenarioName} onChange={e => setScenarioName(e.target.value)}
                placeholder="Scenario name…"
                style={{ ...S.select, flex:1 }}
                onKeyDown={e => e.key==="Enter" && saveScenario()}
              />
              <button onClick={saveScenario} style={S.btnPrimary}>Save</button>
            </div>
            {scenarios.length > 0 && (
              <div style={{ marginTop:14 }}>
                <Table
                  headers={["Name","Total","Price","Margin","Saved"]}
                  rows={scenarios.map(s => [
                    <strong>{s.name}</strong>,
                    `₹${s.total}`, `₹${s.price}`,
                    <span style={{ color:marginColor(s.margin), fontWeight:700 }}>{s.margin}%</span>,
                    <span style={{ fontSize:10, color:"#8892b0" }}>{s.ts}</span>,
                  ])}
                />
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// PAGE: REGION PRICING
// ─────────────────────────────────────────────────────────────────────────────

function PageRegion() {
  const [selProduct, setSelProduct] = useState("TRM");
  const product = PRODUCTS.find(p => p.code === selProduct) || PRODUCTS[0];

  return (
    <>
      <SectionHeader title="Region Pricing" sub="Multi-region price matrix with live FX conversion" />
      <div style={S.panels}>
        {/* Region matrix */}
        <div style={S.panel}>
          <div style={S.panelTitle}>
            Region Price Matrix
            <select value={selProduct} onChange={e => setSelProduct(e.target.value)} style={{ ...S.select, fontSize:11 }}>
              {PRODUCTS.map(p => <option key={p.code} value={p.code}>{p.name}</option>)}
            </select>
          </div>
          {REGIONS.map(r => {
            const res = calcCost({ pr:product.pr, pm:product.pm, oh:product.oh, freight:r.freight, margin:product.margin, fxRate:r.fxr > 1 ? r.fxr : null });
            const display = r.fxr === 1 ? `₹${res.price}` : `${r.currency} ${(res.price/r.fxr).toFixed(2)}`;
            return (
              <div key={r.id} style={{ border:"1px solid #e5e8f0", borderRadius:8, padding:"12px 14px", marginBottom:10 }}>
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:8 }}>
                  <div>
                    <div style={{ fontSize:13, fontWeight:600, color:"#1a1d27" }}>{r.name}</div>
                    <div style={{ fontSize:11, color:"#8892b0", marginTop:2 }}>Freight ₹{r.freight}/kg · {r.currency}{r.fxr!==1?` (₹${r.fxr}/unit)`:""}</div>
                  </div>
                  <Pill status={r.isExport?"export":"domestic"} label={r.isExport?"Export":"Domestic"} />
                </div>
                <div style={{ display:"flex", gap:20 }}>
                  <div><div style={{ fontSize:10, color:"#8892b0" }}>Total Cost</div><div style={{ fontSize:13, fontWeight:600 }}>₹{res.total}</div></div>
                  <div><div style={{ fontSize:10, color:"#8892b0" }}>List Price</div><div style={{ fontSize:13, fontWeight:600, color:"#5b6ef5" }}>{display}</div></div>
                  {r.isExport && <div><div style={{ fontSize:10, color:"#8892b0" }}>Also in ₹</div><div style={{ fontSize:13, fontWeight:600 }}>₹{res.price}</div></div>}
                </div>
              </div>
            );
          })}
        </div>
        {/* FX Rates */}
        <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
          <div style={S.panel}>
            <div style={S.panelTitle}>Live FX Rates <Badge color="#dcfce7" text="#166534">Live</Badge></div>
            <Table
              headers={["Currency","Rate (₹)","Region","Source"]}
              rows={FX_RATES.map(f => [
                <strong>{f.currency}</strong>,
                `₹${f.rate}`,
                f.region,
                <Pill status={f.status} label={f.status.charAt(0).toUpperCase()+f.status.slice(1)} />,
              ])}
            />
          </div>
          <div style={S.panel}>
            <div style={S.panelTitle}>FX Converter</div>
            <FXConverter />
          </div>
        </div>
      </div>
    </>
  );
}

function FXConverter() {
  const [amountInr, setAmountInr] = useState(1000);
  const [currency, setCurrency] = useState("USD");
  const rate = FX_RATES.find(f => f.currency === currency)?.rate || 83.42;
  const converted = (amountInr / rate).toFixed(2);

  return (
    <div>
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr auto", gap:8, alignItems:"end" }}>
        <div>
          <div style={{ fontSize:11, color:"#8892b0", marginBottom:5 }}>Amount in ₹</div>
          <input type="number" value={amountInr} onChange={e => setAmountInr(+e.target.value)}
            style={{ ...S.select, width:"100%" }} />
        </div>
        <div>
          <div style={{ fontSize:11, color:"#8892b0", marginBottom:5 }}>To Currency</div>
          <select value={currency} onChange={e => setCurrency(e.target.value)} style={{ ...S.select, width:"100%" }}>
            {FX_RATES.map(f => <option key={f.currency} value={f.currency}>{f.currency}</option>)}
          </select>
        </div>
      </div>
      <div style={{ marginTop:14, padding:"14px 16px", background:"#f8f9fc", borderRadius:8 }}>
        <div style={{ fontSize:11, color:"#8892b0", marginBottom:4 }}>Result</div>
        <div style={{ fontSize:22, fontWeight:700, color:"#5b6ef5" }}>{currency} {converted}</div>
        <div style={{ fontSize:11, color:"#8892b0", marginTop:4 }}>₹{amountInr} ÷ {rate} = {currency} {converted}</div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// PAGE: FREIGHT MATRIX
// ─────────────────────────────────────────────────────────────────────────────

function PageFreight() {
  const [fcRegion, setFcRegion] = useState(FREIGHT_MATRIX[0]);
  const [fcMode, setFcMode] = useState("local");
  const [fcWeight, setFcWeight] = useState(100);
  const [fcResult, setFcResult] = useState(null);

  const calcFreight = () => {
    const base = fcRegion[fcMode];
    const factor = fcWeight >= 20000 ? 0.8 : fcWeight >= 5000 ? 0.92 : 1.0;
    const rate = +(base * factor).toFixed(2);
    const total = +(rate * (fcWeight / 1000)).toFixed(2);
    setFcResult({ rate, factor, total, base });
  };

  return (
    <>
      <SectionHeader title="Freight Matrix" sub="Zone × Mode pricing with weight-based discounts" />
      <div style={S.panel}>
        <div style={S.panelTitle}>Freight Rate Matrix — ₹/kg <Badge>8 zones · 3 modes</Badge></div>
        <div style={{ overflowX:"auto" }}>
          <Table
            headers={["Region","Local / Sea ₹","Express / Air ₹","Bulk / Express ₹","Type","Weight Discount"]}
            rows={FREIGHT_MATRIX.map(r => [
              <strong>{r.region}</strong>,
              `₹${r.local}`,
              `₹${r.express}`,
              `₹${r.bulk}`,
              <Pill status={r.type} label={r.type.charAt(0).toUpperCase()+r.type.slice(1)} />,
              "−20% on >20kg",
            ])}
          />
        </div>
      </div>
      <div style={S.panels}>
        <div style={S.panel}>
          <div style={S.panelTitle}>Freight Calculator</div>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10, marginBottom:12 }}>
            <div>
              <div style={{ fontSize:11, color:"#8892b0", marginBottom:5 }}>Region</div>
              <select value={fcRegion.region} onChange={e => setFcRegion(FREIGHT_MATRIX.find(r=>r.region===e.target.value))} style={{ ...S.select, width:"100%" }}>
                {FREIGHT_MATRIX.map(r => <option key={r.region} value={r.region}>{r.region}</option>)}
              </select>
            </div>
            <div>
              <div style={{ fontSize:11, color:"#8892b0", marginBottom:5 }}>Mode</div>
              <select value={fcMode} onChange={e => setFcMode(e.target.value)} style={{ ...S.select, width:"100%" }}>
                <option value="local">Local / Sea</option>
                <option value="express">Express / Air</option>
                <option value="bulk">Bulk</option>
              </select>
            </div>
            <div>
              <div style={{ fontSize:11, color:"#8892b0", marginBottom:5 }}>Shipment Weight (kg)</div>
              <input type="number" value={fcWeight} onChange={e => setFcWeight(+e.target.value)}
                style={{ ...S.select, width:"100%" }} />
            </div>
            <div style={{ display:"flex", alignItems:"flex-end" }}>
              <button onClick={calcFreight} style={{ ...S.btnPrimary, width:"100%", padding:"8px 14px" }}>
                Calculate Freight
              </button>
            </div>
          </div>
          {fcResult && (
            <div style={{ padding:"14px 16px", background:"#f0f2f7", borderRadius:8 }}>
              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10 }}>
                {[
                  ["Base Rate", `₹${fcResult.base}/kg`],
                  ["Weight Factor", `×${fcResult.factor}`],
                  ["Final Rate", `₹${fcResult.rate}/kg`],
                  ["Total Freight", <strong style={{ color:"#5b6ef5", fontSize:16 }}>₹{fcResult.total.toLocaleString()}</strong>],
                ].map(([l,v]) => (
                  <div key={l}>
                    <div style={{ fontSize:10, color:"#8892b0", marginBottom:3 }}>{l}</div>
                    <div style={{ fontSize:13, fontWeight:600 }}>{v}</div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
        <div style={S.panel}>
          <div style={S.panelTitle}>Weight Discount Tiers</div>
          <Table
            headers={["Weight Bracket","Discount","Multiplier","Example (Local NI)"]}
            rows={[
              ["< 500 g",      "None",   "×1.00", "₹12.00/kg"],
              ["500 g – 5 kg", "None",   "×1.00", "₹12.00/kg"],
              ["5 kg – 20 kg", "−8%",    "×0.92", "₹11.04/kg"],
              ["> 20 kg",      "−20%",   "×0.80", "₹9.60/kg"],
            ]}
          />
          <div style={{ marginTop:16, padding:"12px 14px", background:"#f0f2f7", borderRadius:8, fontSize:12, color:"#6872a0", lineHeight:1.7 }}>
            <strong style={{ color:"#1a1d27" }}>Export surcharges:</strong><br/>
            EU / US: +₹5 documentation fee per shipment<br/>
            Middle East: +₹3 customs handling per kg<br/>
            SE Asia: ASEAN tariff waiver applies on select items
          </div>
        </div>
      </div>
    </>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// PAGE: AUDIT LOG
// ─────────────────────────────────────────────────────────────────────────────

function PageAudit() {
  const [typeFilter, setTypeFilter] = useState("ALL");
  const [userFilter, setUserFilter] = useState("ALL");

  const filtered = AUDIT_EVENTS.filter(e =>
    (typeFilter === "ALL" || e.type === typeFilter) &&
    (userFilter === "ALL" || e.user === userFilter)
  );

  const users = [...new Set(AUDIT_EVENTS.map(e => e.user))];
  const bgColors = { COST_CHANGE:"#fef9c3", FX_UPDATE:"#dbeafe", BULK_IMPORT:"#ede9fe" };

  return (
    <>
      <SectionHeader title="Audit Log" sub="Complete change history with cost impact tracking" />
      <div style={S.panel}>
        <div style={{ display:"flex", gap:8, marginBottom:16, flexWrap:"wrap" }}>
          <select value={typeFilter} onChange={e => setTypeFilter(e.target.value)} style={S.select}>
            <option value="ALL">All Event Types</option>
            <option value="COST_CHANGE">Cost Change</option>
            <option value="FX_UPDATE">FX Update</option>
            <option value="BULK_IMPORT">Bulk Import</option>
          </select>
          <select value={userFilter} onChange={e => setUserFilter(e.target.value)} style={S.select}>
            <option value="ALL">All Users</option>
            {users.map(u => <option key={u} value={u}>{u}</option>)}
          </select>
          <Badge>{filtered.length} events</Badge>
        </div>
        {filtered.map((e, i) => (
          <div key={i} style={{ display:"flex", alignItems:"flex-start", gap:12, padding:"13px 0", borderBottom:"1px solid #f5f5f7" }}>
            <div style={{ width:36, height:36, borderRadius:9, display:"flex", alignItems:"center", justifyContent:"center", fontSize:16, flexShrink:0, background:bgColors[e.type]||"#f0f2f7" }}>
              {e.icon}
            </div>
            <div style={{ flex:1 }}>
              <div style={{ fontSize:13, fontWeight:500, color:"#1a1d27" }}>
                <strong>{e.field}</strong>: {e.old} → <strong>{e.new_val}</strong>
              </div>
              <div style={{ fontSize:11, color:"#8892b0", marginTop:3 }}>
                {e.sku} · by {e.user} · {e.ts}
              </div>
              <div style={{ fontSize:10, marginTop:5 }}>
                <span style={{ background:"#f0f2f7", padding:"2px 7px", borderRadius:4, color:"#6872a0" }}>{e.type.replace("_"," ")}</span>
              </div>
            </div>
            <div>
              <Pill
                status={e.impactType}
                label={e.impact}
              />
            </div>
          </div>
        ))}
      </div>
      {/* Summary stats */}
      <div style={S.panels}>
        <div style={S.panel}>
          <div style={S.panelTitle}>Impact Summary — Last 30 Days</div>
          <Table
            headers={["Category","Events","Avg Impact","Largest Change"]}
            rows={[
              ["PR Cost changes",   "12", "+2.8%",  "Cardamom +4.3%"],
              ["PM Cost changes",   "5",  "−1.2%",  "Cumin −9.9%"],
              ["Overhead changes",  "3",  "+0.4pp", "Chilli +0.5pp"],
              ["Freight updates",   "7",  "+8.4%",  "EU route +22.2%"],
              ["FX rate updates",   "30", "±0.6%",  "EUR +1.44%"],
              ["Bulk imports",      "3",  "—",      "45K rows"],
            ]}
          />
        </div>
        <div style={S.panel}>
          <div style={S.panelTitle}>Top Cost-Impacting Changes</div>
          <Table
            headers={["SKU","Field","Old","New","Impact"]}
            rows={[
              ["Export — EU", "Freight",  "₹18",   "₹22",   <span style={{color:"#ef4444",fontWeight:700}}>+22.2%</span>],
              ["CDM-250G-EU", "PR",       "₹1150", "₹1200", <span style={{color:"#ef4444",fontWeight:700}}>+4.3%</span>],
              ["TRM-5KG-NI",  "PR",       "₹178",  "₹184",  <span style={{color:"#ef4444",fontWeight:700}}>+3.4%</span>],
              ["CUM-100G-SI", "PM",       "₹14.2", "₹12.8", <span style={{color:"#22c55e",fontWeight:700}}>−9.9%</span>],
              ["FX — EUR",    "Rate",     "88.90", "90.18", <span style={{color:"#f59e0b",fontWeight:700}}>+1.4%</span>],
            ]}
          />
        </div>
      </div>
    </>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// PAGE: BULK IMPORT
// ─────────────────────────────────────────────────────────────────────────────

function PageBulkImport() {
  const [jobState, setJobState] = useState(null); // null | "running" | "done" | "error"
  const [progress, setProgress] = useState(0);
  const [dragOver, setDragOver] = useState(false);

  const startImport = useCallback(() => {
    setJobState("running");
    setProgress(0);
    const messages = ["Parsing file…","Validating columns…","Checking product types…","Computing costs…","Bulk writing to MongoDB…","Finalising…"];
    let pct = 0;
    const iv = setInterval(() => {
      pct = Math.min(pct + 14, 100);
      setProgress(pct);
      if (pct >= 100) { clearInterval(iv); setJobState("done"); }
    }, 350);
  }, []);

  const RECENT = [
    { date:"2025-05-14", file:"q2_skus.xlsx",         rows:"12,400",  errors:3,   status:"done"    },
    { date:"2025-05-01", file:"region_costs.csv",     rows:"8,200",   errors:0,   status:"done"    },
    { date:"2025-04-18", file:"bulk_pr_update.csv",   rows:"45,000",  errors:12,  status:"partial" },
    { date:"2025-04-02", file:"cardamom_sku.xlsx",    rows:"1,200",   errors:0,   status:"done"    },
    { date:"2025-03-15", file:"export_pricing.csv",   rows:"3,800",   errors:45,  status:"partial" },
  ];

  const COLUMNS = ["sku_code","product_type","pr_cost_per_kg","pm_cost_per_unit","overhead_rate","freight_cost_kg","region_id","target_margin","weight_grams","pack_type"];

  return (
    <>
      <SectionHeader title="Bulk Import" sub="Upload CSV or Excel to update 300K SKU cost records" />
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:14 }}>
        {/* Upload zone */}
        <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
          <div style={S.panel}>
            <div style={S.panelTitle}>Upload File</div>
            <div
              onDragOver={e => { e.preventDefault(); setDragOver(true); }}
              onDragLeave={() => setDragOver(false)}
              onDrop={e => { e.preventDefault(); setDragOver(false); startImport(); }}
              onClick={startImport}
              style={{
                border:`2px dashed ${dragOver?"#5b6ef5":"#c8ceea"}`,
                borderRadius:10, padding:"36px 20px", textAlign:"center", cursor:"pointer",
                background: dragOver ? "#f5f6ff" : "#f8f9fc",
                transition:"all .2s",
              }}
            >
              <div style={{ fontSize:36, marginBottom:10 }}>📤</div>
              <div style={{ fontSize:13, fontWeight:500, color:"#1a1d27", marginBottom:5 }}>
                Click or drag & drop your file
              </div>
              <div style={{ fontSize:11, color:"#8892b0" }}>CSV or Excel (.xlsx) · Max 300K rows</div>
            </div>
            <div style={{ marginTop:14 }}>
              <div style={{ fontSize:12, fontWeight:700, color:"#1a1d27", marginBottom:8 }}>Required columns:</div>
              <div style={{ display:"flex", flexWrap:"wrap", gap:6 }}>
                {COLUMNS.map(c => <Pill key={c} status="neu" label={c} />)}
              </div>
            </div>
            <div style={{ marginTop:14, padding:"12px 14px", background:"#f0f2f7", borderRadius:8, fontSize:11, color:"#6872a0", lineHeight:1.8 }}>
              <strong style={{ color:"#1a1d27" }}>Validation rules:</strong><br/>
              · product_type must be one of 12 defined types<br/>
              · overhead_rate: 5%–60% · target_margin: 5%–80%<br/>
              · weight_grams: positive integer<br/>
              · Duplicate sku_code → upsert (update existing)
            </div>
          </div>
        </div>
        {/* Status + recent */}
        <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
          <div style={S.panel}>
            <div style={S.panelTitle}>Import Status</div>
            {!jobState && (
              <div style={{ fontSize:13, color:"#8892b0", textAlign:"center", padding:"30px 0" }}>
                No active import job.<br/>Upload a file to begin.
              </div>
            )}
            {jobState === "running" && (
              <>
                <div style={{ marginBottom:10 }}>
                  <div style={{ fontSize:12, color:"#4a5270", marginBottom:5 }}>
                    Processing rows… ({progress}%)
                  </div>
                  <div style={{ height:8, background:"#e8eaf2", borderRadius:4, overflow:"hidden" }}>
                    <div style={{ height:"100%", borderRadius:4, background:"linear-gradient(90deg,#5b6ef5,#a78bfa)", width:`${progress}%`, transition:"width .3s" }} />
                  </div>
                </div>
                {["Parsing file","Validating columns","Checking product types","Computing costs","Writing to MongoDB"].map((step, i) => (
                  <div key={i} style={{ display:"flex", alignItems:"center", gap:8, marginBottom:6 }}>
                    <span style={{ fontSize:14 }}>{progress >= (i+1)*20 ? "✅" : "⏳"}</span>
                    <span style={{ fontSize:12, color: progress >= (i+1)*20 ? "#1a1d27" : "#8892b0" }}>{step}</span>
                  </div>
                ))}
              </>
            )}
            {jobState === "done" && (
              <div style={{ padding:"16px", background:"#dcfce7", borderRadius:8, textAlign:"center" }}>
                <div style={{ fontSize:24, marginBottom:8 }}>✅</div>
                <div style={{ fontSize:14, fontWeight:700, color:"#166534" }}>Import Complete</div>
                <div style={{ fontSize:12, color:"#166534", marginTop:4 }}>
                  12,400 rows · 3 errors · 0 duplicates
                </div>
                <button onClick={() => setJobState(null)} style={{ ...S.btn, marginTop:12, fontSize:11 }}>
                  Clear
                </button>
              </div>
            )}
          </div>
          <div style={S.panel}>
            <div style={S.panelTitle}>Recent Imports <Badge>{RECENT.length}</Badge></div>
            <Table
              headers={["Date","File","Rows","Errors","Status"]}
              rows={RECENT.map(r => [
                <span style={{ fontSize:11, color:"#8892b0" }}>{r.date}</span>,
                <span style={{ fontFamily:"monospace", fontSize:11 }}>{r.file}</span>,
                r.rows,
                <span style={{ color: r.errors > 0 ? "#f59e0b" : "#22c55e", fontWeight:600 }}>{r.errors}</span>,
                <Pill status={r.status} label={r.status.charAt(0).toUpperCase()+r.status.slice(1)} />,
              ])}
            />
          </div>
        </div>
      </div>
    </>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN APP
// ─────────────────────────────────────────────────────────────────────────────

const NAV = [
  { id:"dashboard", icon:"◈", label:"Dashboard",      section:"Overview"       },
  { id:"sku",       icon:"⊟", label:"SKU Explorer",   section:"Overview"       },
  { id:"cost",      icon:"◇", label:"Cost Breakdown", section:"Cost Analysis"  },
  { id:"sim",       icon:"⚡", label:"Cost Simulator", section:"Cost Analysis"  },
  { id:"region",    icon:"🌏", label:"Region Pricing", section:"Geography"      },
  { id:"freight",   icon:"🚛", label:"Freight Matrix", section:"Geography"      },
  { id:"audit",     icon:"≡", label:"Audit Log",      section:"Admin"          },
  { id:"import",    icon:"↑", label:"Bulk Import",    section:"Admin"          },
];

const PAGES = {
  dashboard: PageDashboard,
  sku:       PageSKU,
  cost:      PageCostBreakdown,
  sim:       PageSimulator,
  region:    PageRegion,
  freight:   PageFreight,
  audit:     PageAudit,
  import:    PageBulkImport,
};

const SECTIONS = [...new Set(NAV.map(n => n.section))];

export default function SpiceCostPro() {
  const [page, setPage] = useState("dashboard");
  const [quarter, setQuarter] = useState("Q2 2025");
  const [regionF, setRegionF] = useState("all");

  const PageComponent = PAGES[page] || PageDashboard;

  return (
    <div style={S.shell}>
      {/* SIDEBAR */}
      <div style={S.sidebar}>
        <div style={S.sbLogo}>
          <div style={S.sbBrand}><span>🌶</span>SpiceCost Pro</div>
          <div style={S.sbSub}>Manufacturing Analytics</div>
        </div>
        {SECTIONS.map(section => (
          <div key={section}>
            <div style={S.sbSection}>{section}</div>
            {NAV.filter(n => n.section === section).map(n => (
              <NavItem
                key={n.id}
                icon={n.icon}
                label={n.label}
                active={page === n.id}
                onClick={() => setPage(n.id)}
              />
            ))}
          </div>
        ))}
        <div style={S.sbFoot}>
          <div style={S.sbFootRole}>Admin</div>
          <div style={S.sbFootUser}>admin@spicecost.com</div>
        </div>
      </div>

      {/* MAIN */}
      <div style={S.main}>
        {/* TOPBAR */}
        <div style={S.topbar}>
          <span style={{ fontSize:15, fontWeight:700, color:"#1a1d27" }}>
            {NAV.find(n => n.id === page)?.label}
          </span>
          <div style={{ display:"flex", gap:8, alignItems:"center" }}>
            <select value={quarter} onChange={e => setQuarter(e.target.value)} style={S.select}>
              <option>Q2 2025</option><option>Q1 2025</option><option>Q4 2024</option><option>Q3 2024</option>
            </select>
            <select value={regionF} onChange={e => setRegionF(e.target.value)} style={S.select}>
              <option value="all">All Regions</option>
              {REGIONS.map(r => <option key={r.id} value={r.id}>{r.name}</option>)}
            </select>
            <button style={S.btnPrimary} onClick={() => alert("Generating report…")}>↓ Export</button>
          </div>
        </div>

        {/* PAGE CONTENT */}
        <div style={S.content}>
          <PageComponent quarter={quarter} regionFilter={regionF} />
        </div>
      </div>
    </div>
  );
}
