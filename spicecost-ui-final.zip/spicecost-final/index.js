import React from "react";
import ReactDOM from "react-dom/client";
import SpiceCostPro from "./SpiceCostPro";

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<SpiceCostPro />);
